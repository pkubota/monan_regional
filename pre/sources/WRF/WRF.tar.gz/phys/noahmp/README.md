# Noah-MP version 4.5 release


This is the official Noah-MP code version 4.5 consistent with that released in WRF v4.5. Note that WRF v4.5 GitHub code is directly connected to this Noah-MP GitHub through the submodule mechanism. 

