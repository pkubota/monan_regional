"""run_all.py: roda as quatro analises do slide 20 (ou so as escolhidas).

Uso:
    python run_all.py experimentos.toml
    python run_all.py experimentos.toml --so ruido espectro
"""
import argparse

import fm_common as fm
import m1_ruido
import m2_espectro
import m3_estabilidade
import m4_impacto

ETAPAS = {
    "ruido": m1_ruido.main,
    "espectro": m2_espectro.main,
    "estabilidade": m3_estabilidade.main,
    "impacto": m4_impacto.main,
}

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("config")
    ap.add_argument("--so", nargs="+", choices=list(ETAPAS), help="rodar apenas estas etapas")
    a = ap.parse_args()
    cfg = fm.carrega_config(a.config)
    for nome in a.so or ETAPAS:
        print(f"== {nome} ==")
        ETAPAS[nome](cfg)
    print("Concluido. Resultados em:", cfg["geral"]["saida"])
