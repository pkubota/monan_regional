"""m4_impacto.py: metrica 4 do slide 20 (impacto no tempo).

Para cada variavel de [impacto].variaveis, compara cada experimento ao controle no
mesmo nivel e instante:
  - rmse, vies : ponderados pela area das celulas, na malha nativa;
  - mapa de diferenca (exp - controle) na grade lat-lon.
E o custo computacional a partir do log: tempo medio por passo e variacao relativa ao controle.
Saidas: impacto_resumo.csv, impacto_<var>_<serie>.png e impacto_custo.png.
"""
from __future__ import annotations

import argparse

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import fm_common as fm


def main(cfg: dict) -> pd.DataFrame:
    c = cfg["impacto"]
    nivel = int(c.get("nivel", cfg["geral"]["nivel"]))
    variaveis = c.get("variaveis", ["theta", "uReconstructZonal"])
    tempos = "ultimo"
    ctrl = cfg["geral"]["controle"]
    malha = fm.carrega_malha(cfg)
    rg = fm.Regrade(malha, cfg)

    ref = {v: fm.le_campo(cfg["experimentos"][ctrl], v, nivel, tempos) for v in variaveis}
    linhas, difs = [], {}
    for nome, exp in fm.experimentos(cfg).items():
        for v in variaveis:
            xt, a = fm.le_campo(exp, v, nivel, tempos)
            d = a[-1] - ref[v][1][-1]
            difs[(nome, v)] = d
            linhas.append({
                "exp": nome, "serie": fm.serie_de(cfg, nome), "variavel": v, "tempo": xt[-1],
                "rmse": float(np.sqrt(np.sum(malha.area * d**2) / malha.area.sum())),
                "vies": float(np.sum(malha.area * d) / malha.area.sum()),
            })
    df = pd.DataFrame(linhas)

    # custo computacional
    custo = []
    for nome, exp in fm.experimentos(cfg).items():
        if "log" in exp:
            t = fm.le_log(exp["log"])["timings"]
            custo.append({"exp": nome, "passos_cronometrados": len(t),
                          "s_por_passo": float(np.mean(t)) if t else np.nan})
    dc = pd.DataFrame(custo)
    if len(dc) and ctrl in set(dc.exp):
        base = float(dc.loc[dc.exp == ctrl, "s_por_passo"].iloc[0])
        dc["custo_rel_pct"] = (dc.s_por_passo / base - 1.0) * 100.0
        df = df.merge(dc, on="exp", how="left")
    fm.salva_csv(df, "impacto_resumo.csv", cfg)

    # mapas de diferenca por serie e variavel
    for v in variaveis:
        for serie, nomes in fm.series(cfg).items():
            outros = [n for n in nomes if n != ctrl]
            mapas = {n: rg(difs[(n, v)]) for n in outros}
            vmax = np.nanpercentile(np.abs(np.concatenate([m.ravel() for m in mapas.values()])), 98)
            vmax = vmax if vmax > 0 else 1.0
            nc = min(3, len(outros))
            nl = int(np.ceil(len(outros) / nc))
            fig, axs = plt.subplots(nl, nc, figsize=(4.8 * nc, 3.4 * nl), squeeze=False)
            for ax, n in zip(axs.ravel(), outros):
                im = ax.pcolormesh(rg.lon, rg.lat, mapas[n], cmap="RdBu_r", vmin=-vmax, vmax=vmax,
                                   shading="auto")
                r = df[(df.exp == n) & (df.variavel == v)].rmse.iloc[0]
                ax.set_title(f"{n} - {ctrl}  (RMSE {r:.3g})", fontsize=9)
                ax.set_xlabel("lon (graus)", fontsize=8)
                ax.set_ylabel("lat (graus)", fontsize=8)
            for ax in axs.ravel()[len(outros):]:
                ax.axis("off")
            fig.colorbar(im, ax=axs.ravel().tolist(), shrink=0.8, label=v)
            fig.suptitle(f"Serie {serie}: diferenca para o controle, {v}, nivel {nivel}",
                         fontweight="bold", y=1.03)
            fm.salva_fig(fig, f"impacto_{v}_{serie}.png", cfg)

    if len(dc) and "custo_rel_pct" in dc:
        fig, ax = plt.subplots(figsize=(max(6, 0.6 * len(dc)), 3.8))
        ax.bar(dc.exp, dc.custo_rel_pct, color="#17788A")
        ax.axhline(0, color="k", lw=0.8)
        ax.set_ylabel("variacao do tempo por passo (%)")
        ax.set_title("Custo computacional relativo ao controle")
        plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
        fig.tight_layout()
        fm.salva_fig(fig, "impacto_custo.png", cfg)
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("config")
    main(fm.carrega_config(ap.parse_args().config))
