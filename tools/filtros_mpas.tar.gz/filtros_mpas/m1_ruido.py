"""m1_ruido.py: metrica 1 do slide 20 (ruido).

Por experimento e instante:
  - rug_<var>  : rugosidade 2dx = RMS de (phi_i - media dos vizinhos), na malha nativa
                 (ponderada pela area). Sem cellsOnCell, cai para o laplaciano de 5 pontos
                 na grade lat-lon regradeada.
  - rms_div, rms_vort : RMS da divergencia horizontal e da vorticidade vertical (s^-1),
                 da grade lat-lon, em todas as escalas.
  - rms_div_2dx, rms_vort_2dx : o mesmo, mas so do que sobra apos remover a media local 3x3
                 (passa-alta, escalas de poucos dx). E o indicador de ruido; as versoes
                 sem filtro sao dominadas por jato e ondas longas.
  - wmax_topo  : maximo de |w| nos ultimos `n_niveis_topo` niveis do modelo.
Saidas: ruido_metricas.csv e ruido_<serie>.png.
"""
from __future__ import annotations

import argparse

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.ndimage import uniform_filter

import fm_common as fm


def passa_alta(x):
    """x menos a media local 3x3 (ignora NaN): realca as escalas de poucos dx."""
    ok = np.isfinite(x).astype(float)
    num = uniform_filter(np.where(ok > 0, x, 0.0), size=3, mode="nearest")
    den = uniform_filter(ok, size=3, mode="nearest")
    return np.where(ok > 0, x - num / np.maximum(den, 1e-9), np.nan)


def rugosidade_nativa(campo, malha):
    viz = np.where(malha.mask, campo[malha.viz], 0.0).sum(1) / malha.mask.sum(1)
    d = campo - viz
    return float(np.sqrt(np.sum(malha.area * d**2) / malha.area.sum()))


def rugosidade_latlon(g):
    """Laplaciano de 5 pontos na grade regradeada (alternativa sem cellsOnCell)."""
    viz = 0.25 * (g[:-2, 1:-1] + g[2:, 1:-1] + g[1:-1, :-2] + g[1:-1, 2:])
    d = g[1:-1, 1:-1] - viz
    return float(np.sqrt(np.nanmean(d**2)))


def div_vort(u, v, lat_deg, lon_deg):
    """Divergencia e vorticidade em lat-lon: u, v [nlat, nlon] em m/s."""
    lat, lon = np.deg2rad(lat_deg), np.deg2rad(lon_deg)
    dlam, dphi = lon[1] - lon[0], lat[1] - lat[0]
    cos = np.cos(lat)[:, None]
    div = (np.gradient(u, dlam, axis=1) + np.gradient(v * cos, dphi, axis=0)) / (fm.R_TERRA * cos)
    vort = (np.gradient(v, dlam, axis=1) - np.gradient(u * cos, dphi, axis=0)) / (fm.R_TERRA * cos)
    return div, vort


def main(cfg: dict) -> pd.DataFrame:
    c = cfg["ruido"]
    nivel = int(c.get("nivel", cfg["geral"]["nivel"]))
    vars_rug = c.get("variaveis_rugosidade", ["theta"])
    ntopo = int(c.get("n_niveis_topo", 5))
    tempos = cfg["geral"]["tempos"]
    malha = fm.carrega_malha(cfg)
    rg = fm.Regrade(malha, cfg)
    linhas = []
    for nome, exp in fm.experimentos(cfg).items():
        print(f"[ruido] {nome}")
        xt, uz = fm.le_campo(exp, c.get("u", "uReconstructZonal"), nivel, tempos)
        _, vm = fm.le_campo(exp, c.get("v", "uReconstructMeridional"), nivel, tempos)
        rug = {}
        for var in vars_rug:
            try:
                rug[var] = fm.le_campo(exp, var, nivel, tempos)[1]
            except KeyError as e:
                print(f"  aviso: {e}")
        try:
            _, w = fm.le_campo(exp, c.get("w", "w"), slice(-ntopo, None), tempos)
            wmax = np.abs(w).reshape(w.shape[0], -1).max(1)
        except KeyError as e:
            print(f"  aviso: {e}")
            wmax = np.full(len(xt), np.nan)
        h = fm.horas(xt)
        for i, t in enumerate(xt):
            u2, v2 = rg(uz[i]), rg(vm[i])
            div, vort = div_vort(u2, v2, rg.lat, rg.lon)
            reg = {
                "exp": nome, "serie": fm.serie_de(cfg, nome), "tempo": t, "horas": h[i],
                "rms_div": fm.rms_ponderado(div, rg.peso_lat),
                "rms_vort": fm.rms_ponderado(vort, rg.peso_lat),
                "rms_div_2dx": fm.rms_ponderado(passa_alta(div), rg.peso_lat),
                "rms_vort_2dx": fm.rms_ponderado(passa_alta(vort), rg.peso_lat),
                "wmax_topo": wmax[i],
            }
            for var, a in rug.items():
                reg[f"rug_{var}"] = (
                    rugosidade_nativa(a[i], malha) if malha.viz is not None
                    else rugosidade_latlon(rg(a[i]))
                )
            linhas.append(reg)
    df = pd.DataFrame(linhas)
    fm.salva_csv(df, "ruido_metricas.csv", cfg)

    colunas = [f"rug_{v}" for v in vars_rug if f"rug_{v}" in df] + [
        "rms_div_2dx", "rms_vort_2dx", "wmax_topo"]
    rotulos = {"rms_div_2dx": "RMS divergencia, escalas de poucos dx (s^-1)",
               "rms_vort_2dx": "RMS vorticidade, escalas de poucos dx (s^-1)",
               "wmax_topo": f"max |w| nos {ntopo} niveis do topo (m/s)"}
    for serie, nomes in fm.series(cfg).items():
        nl = int(np.ceil(len(colunas) / 2))
        fig, axs = plt.subplots(nl, 2, figsize=(11, 3.8 * nl), squeeze=False)
        for ax in axs.ravel()[len(colunas):]:
            ax.axis("off")
        for ax, col in zip(axs.ravel(), colunas):
            for i, n in enumerate(nomes):
                d = df[df.exp == n]
                if len(d) > 1:
                    ax.plot(d.horas, d[col], label=n, **fm.estilo(n, cfg, i))
                else:
                    ax.plot(i, d[col].iloc[0], "o", label=n, color=fm.estilo(n, cfg, i)["color"])
            ax.set_title(rotulos.get(col, col.replace("rug_", "rugosidade 2dx de ")), fontsize=10)
            ax.set_xlabel("horas" if len(d) > 1 else "experimento")
            ax.set_yscale("log")
            ax.grid(alpha=0.3)
        axs[0, 0].legend(fontsize=8)
        fig.suptitle(f"Serie {serie}: ruido", fontweight="bold")
        fig.tight_layout()
        fm.salva_fig(fig, f"ruido_{serie}.png", cfg)
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("config")
    main(fm.carrega_config(ap.parse_args().config))
