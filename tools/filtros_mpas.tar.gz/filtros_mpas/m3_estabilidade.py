"""m3_estabilidade.py: metrica 3 do slide 20 (estabilidade).

Le o log do modelo (rank 0). Para os minimos e maximos globais de u e w a cada passo
e preciso `config_print_global_minmax_vel = true` no namelist. Por experimento informa:
  - se o log termina normalmente e quantos passos foram feitos;
  - max|u| e max|w| ao longo da integracao;
  - primeiro passo com |u| > limite_vento ou valor nao finito (provavel explosao).
Saidas: estabilidade_resumo.csv e estabilidade_<serie>.png.

ATENCAO: o formato exato da linha de min/max varia com a versao. O padrao procurado e
  "global min, max <var> <min> <max>"
Se o seu log for diferente, informe uma regex propria em [estabilidade].regex_minmax,
com tres grupos: nome da variavel, minimo, maximo.
"""
from __future__ import annotations

import argparse

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import fm_common as fm


def serie_extremos(log: dict, var: str):
    """max(|min|, |max|) por passo para `var` (NaN se ausente)."""
    return np.array([max(abs(p[var][0]), abs(p[var][1])) if var in p else np.nan
                     for p in log["passos"]])


def main(cfg: dict) -> pd.DataFrame:
    c = cfg["estabilidade"]
    lim = float(c.get("limite_vento", 150.0))
    rx = c.get("regex_minmax")
    logs, linhas = {}, []
    for nome, exp in fm.experimentos(cfg).items():
        print(f"[estabilidade] {nome}")
        if "log" not in exp:
            print("  aviso: sem 'log' na configuracao")
            continue
        lg = fm.le_log(exp["log"], rx)
        logs[nome] = lg
        u, w = serie_extremos(lg, "u"), serie_extremos(lg, "w")
        if np.all(np.isnan(u)):
            print("  aviso: nenhuma linha de min/max; ligue config_print_global_minmax_vel")
        ruim = np.where(~np.isfinite(u) | (u > lim))[0]
        ruim = [i for i in ruim if not (np.isnan(u[i]) and np.all(np.isnan(u)))]
        linhas.append({
            "exp": nome, "serie": fm.serie_de(cfg, nome),
            "passos_no_log": len(lg["passos"]),
            "terminou_normal": lg["terminou"],
            "ultimo_tempo": lg["passos"][-1]["tempo"] if lg["passos"] else "",
            "max_abs_u": float(np.nanmax(u)) if np.any(np.isfinite(u)) else np.nan,
            "max_abs_w": float(np.nanmax(w)) if np.any(np.isfinite(w)) else np.nan,
            "passo_explosao": int(ruim[0]) if len(ruim) else -1,
            "erros": " | ".join(lg["erros"][:2]),
        })
    df = pd.DataFrame(linhas)
    fm.salva_csv(df, "estabilidade_resumo.csv", cfg)

    for serie, nomes in fm.series(cfg).items():
        fig, axs = plt.subplots(1, 2, figsize=(12, 4.5))
        for i, n in enumerate(nomes):
            if n not in logs:
                continue
            est = fm.estilo(n, cfg, i)
            axs[0].plot(serie_extremos(logs[n], "u"), label=n, **est)
            axs[1].plot(serie_extremos(logs[n], "w"), label=n, **est)
        axs[0].axhline(lim, color="r", ls=":", lw=1)
        axs[0].set_title("max |u| global (m/s); tracejado = limite")
        axs[1].set_title("max |w| global (m/s)")
        for a in axs:
            a.set_xlabel("passo de tempo")
            a.set_yscale("log")
            a.grid(alpha=0.3)
        axs[0].legend(fontsize=8)
        fig.suptitle(f"Serie {serie}: estabilidade", fontweight="bold")
        fig.tight_layout()
        fm.salva_fig(fig, f"estabilidade_{serie}.png", cfg)
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("config")
    main(fm.carrega_config(ap.parse_args().config))
