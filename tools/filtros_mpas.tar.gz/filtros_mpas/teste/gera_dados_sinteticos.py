"""gera_dados_sinteticos.py: cria uma malha esferica e saidas "tipo MPAS" sinteticas.

Serve APENAS para testar os scripts de analise (formato de arquivos, logs, metricas).
Os campos nao sao fisica: o vento e um jato mais ondas com espectro vermelho, somados a
ruido branco por celula; cada experimento muda a forca do suavizador e o nivel de ruido,
de modo que o resultado esperado das metricas e conhecido de antemao.

Uso: python gera_dados_sinteticos.py [diretorio_saida] [n_celulas]
"""
import os
import sys

import netCDF4
import numpy as np
from scipy.sparse import coo_matrix
from scipy.spatial import ConvexHull, SphericalVoronoi

R = 6371229.0
SAIDA = sys.argv[1] if len(sys.argv) > 1 else "dados_sinteticos"
N = int(sys.argv[2]) if len(sys.argv) > 2 else 24000
NZ, NT = 12, 4
os.makedirs(SAIDA, exist_ok=True)
rng = np.random.default_rng(42)

# --- malha: pontos de Fibonacci na esfera; vizinhos pela triangulacao (casca convexa) ------
i = np.arange(N) + 0.5
lat = np.arcsin(1 - 2 * i / N)
lon = (np.pi * (1 + 5**0.5) * i) % (2 * np.pi)
xyz = np.column_stack([np.cos(lat) * np.cos(lon), np.cos(lat) * np.sin(lon), np.sin(lat)])
tri = ConvexHull(xyz).simplices
a, b, c = tri[:, 0], tri[:, 1], tri[:, 2]
lin = np.concatenate([a, b, c, b, c, a])
col = np.concatenate([b, c, a, a, b, c])
adj = coo_matrix((np.ones(lin.size), (lin, col)), shape=(N, N)).tocsr()
adj.data[:] = 1.0
grau = np.diff(adj.indptr)
maxe = int(grau.max())
cells = np.zeros((N, maxe), dtype="i4")
for k in range(N):
    viz = adj.indices[adj.indptr[k]:adj.indptr[k + 1]]
    cells[k, :viz.size] = viz + 1  # 1-based, como no MPAS
area = SphericalVoronoi(xyz, radius=1.0).calculate_areas() * R**2
media = adj.multiply(1.0 / grau[:, None]).tocsr()  # operador "media dos vizinhos"


def suaviza(x, passes, alfa=0.5):
    for _ in range(passes):
        x = (1 - alfa) * x + alfa * (media @ x)
    return x


def escreve_malha(caminho, completa=True):
    with netCDF4.Dataset(caminho, "w") as ds:
        ds.createDimension("nCells", N)
        ds.createDimension("maxEdges", maxe)
        for nome, v in (("latCell", lat), ("lonCell", lon), ("areaCell", area)):
            ds.createVariable(nome, "f8", ("nCells",))[:] = v
        if completa:
            ds.createVariable("nEdgesOnCell", "i4", ("nCells",))[:] = grau
            ds.createVariable("cellsOnCell", "i4", ("nCells", "maxEdges"))[:] = cells


escreve_malha(f"{SAIDA}/grid.nc")
escreve_malha(f"{SAIDA}/grid_sem_vizinhos.nc", completa=False)

# --- campos-base ---------------------------------------------------------------------------
env = np.sqrt(np.cos(lat))
u0 = 28 * np.exp(-(((lat - 0.70) / 0.35) ** 2)) + 22 * np.exp(-(((lat + 0.70) / 0.35) ** 2))
v0 = np.zeros(N)
for m in range(1, 41):
    amp = 6.0 * m**-1.2
    u0 = u0 + amp * np.cos(m * lon + rng.uniform(0, 6.28) + 3 * lat) * env
    v0 = v0 + amp * np.cos(m * lon + rng.uniform(0, 6.28) - 2 * lat) * env
th0 = 300 + 25 * np.sin(lat) + sum(
    1.5 * m**-1.0 * np.cos(m * lon + rng.uniform(0, 6.28)) * env for m in range(1, 25))
ru, rv, rth = (rng.standard_normal(N) for _ in range(3))
rw = rng.standard_normal((N, NZ + 1))

# (nome, serie, passes, ruido_u, amp_w_topo, ruido_theta, explode, custo_relativo)
EXPS = [
    ("CTRL", "controle", 1, 0.30, 1.0, 0.10, False, 1.00),
    ("A1", "A", 3, 0.30, 1.0, 0.10, False, 1.02),
    ("A2", "A", 0, 0.30, 1.0, 0.10, False, 0.99),
    ("B1", "B", 1, 0.55, 1.0, 0.10, False, 1.00),
    ("B3", "B", 1, 0.30, 6.0, 0.10, False, 1.00),
    ("B4", "B", 1, 0.30, 1.0, 0.10, True, 1.00),
    ("C1", "C", 2, 0.30, 1.0, 0.10, False, 1.01),
    ("D3", "D", 1, 0.30, 1.0, 0.50, False, 0.97),
]
TIMES = [f"2014-09-10_{h:02d}:00:00" for h in (0, 6, 12, 18)]
ESC = np.linspace(0.8, 1.2, NZ)  # variacao vertical simples

for nome, serie, passes, s_u, a_w, s_th, explode, custo in EXPS:
    d = f"{SAIDA}/run_{nome}"
    os.makedirs(d, exist_ok=True)
    for arq, tt in enumerate((range(0, 2), range(2, 4))):
        with netCDF4.Dataset(f"{d}/history.{arq}.nc", "w") as ds:
            ds.createDimension("Time", None)
            ds.createDimension("nCells", N)
            ds.createDimension("nVertLevels", NZ)
            ds.createDimension("nVertLevelsP1", NZ + 1)
            ds.createDimension("StrLen", 64)
            xt = ds.createVariable("xtime", "S1", ("Time", "StrLen"))
            vu = ds.createVariable("uReconstructZonal", "f4", ("Time", "nCells", "nVertLevels"))
            vv = ds.createVariable("uReconstructMeridional", "f4", ("Time", "nCells", "nVertLevels"))
            vw = ds.createVariable("w", "f4", ("Time", "nCells", "nVertLevelsP1"))
            vt = ds.createVariable("theta", "f4", ("Time", "nCells", "nVertLevels"))
            for j, it in enumerate(tt):
                cresc = 1 + 0.15 * it
                u = suaviza(u0 + s_u * cresc * ru, passes)
                v = suaviza(v0 + s_u * cresc * rv, passes)
                th = suaviza(th0 + s_th * cresc * rth, passes)
                w = 0.03 * rw * cresc
                w[:, -3:] *= a_w * (1 + it)  # sem camada de absorcao, w cresce no topo
                xt[j, :] = netCDF4.stringtochar(np.array([TIMES[it].ljust(64)], "S64"))[0]
                vu[j] = u[:, None] * ESC
                vv[j] = v[:, None] * ESC
                vt[j] = th[:, None] + np.linspace(0, 30, NZ)
                vw[j] = w
    # log do modelo (rank 0)
    nsteps = 96
    with open(f"{d}/log.atmosphere.0000.out", "w") as f:
        f.write(" Reading namelist.atmosphere\n")
        for s in range(nsteps):
            tempo = f"2014-09-10_{(s * 18) // 60:02d}:{(s * 18) % 60:02d}:00"
            umax = 40 + 0.05 * s
            if explode and s > 55:
                umax = 40 * 1.12 ** (s - 55)
            f.write(f" Begin timestep {tempo}\n")
            if explode and s > 80:
                f.write(" global min, max u  NaN NaN\n")
                f.write(" global min, max w  NaN NaN\n")
                f.write(" CRITICAL ERROR: NaN detected in prognostic fields\n")
                break
            f.write(f" global min, max u  {-0.6 * umax:12.5f} {umax:12.5f}\n")
            f.write(f" global min, max w  {-0.8 - 0.002 * s:12.5f} {1.1 + 0.003 * s:12.5f}\n")
            f.write(f" Timing for integration step: {0.50 * custo * (1 + 0.04 * rng.standard_normal()):.4f} s\n")
        else:
            f.write(" Finished running the atmosphere core\n")
print(f"Dados sinteticos em {SAIDA}: {N} celulas, dx ~ {np.sqrt(2 * area.mean() / 3**0.5) / 1e3:.0f} km")
