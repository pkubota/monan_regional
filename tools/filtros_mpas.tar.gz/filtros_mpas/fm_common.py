"""fm_common.py: utilidades comuns aos scripts de analise dos filtros do MPAS/MONAN.

Le a configuracao (TOML), as saidas NetCDF do MPAS (malha nao estruturada),
os logs do modelo e faz o regrade para lat-lon (vizinho mais proximo).
Dependencias: numpy, scipy, xarray, netCDF4, pandas, matplotlib.
"""
from __future__ import annotations

import glob
import os
import re
from datetime import datetime

try:
    import tomllib  # Python >= 3.11
except ImportError:  # Python < 3.11: pip install tomli
    import tomli as tomllib

import numpy as np
import xarray as xr
from scipy.spatial import cKDTree

R_TERRA = 6371229.0  # raio da esfera usado pelo MPAS (m)

# ----------------------------------------------------------------------------
# Configuracao
# ----------------------------------------------------------------------------


def carrega_config(caminho: str) -> dict:
    with open(caminho, "rb") as f:
        cfg = tomllib.load(f)
    cfg.setdefault("geral", {})
    cfg["geral"].setdefault("saida", "figuras_filtros")
    cfg["geral"].setdefault("controle", "CTRL")
    cfg["geral"].setdefault("nivel", 10)
    cfg["geral"].setdefault("tempos", "ultimo")  # "ultimo" ou "todos"
    for k in ("ruido", "espectro", "estabilidade", "impacto"):
        cfg.setdefault(k, {})
    if cfg["geral"]["controle"] not in cfg.get("experimentos", {}):
        raise KeyError("O experimento de controle nao esta em [experimentos.*]")
    os.makedirs(cfg["geral"]["saida"], exist_ok=True)
    return cfg


def experimentos(cfg: dict) -> dict:
    return cfg["experimentos"]


def series(cfg: dict) -> dict[str, list[str]]:
    """Agrupa os experimentos por serie; o controle abre cada grupo."""
    ctrl = cfg["geral"]["controle"]
    grupos: dict[str, list[str]] = {}
    for nome, e in cfg["experimentos"].items():
        if nome == ctrl:
            continue
        grupos.setdefault(e.get("serie", "outros"), []).append(nome)
    return {s: [ctrl] + nomes for s, nomes in grupos.items()}


def serie_de(cfg: dict, nome: str) -> str:
    return cfg["experimentos"][nome].get("serie", "controle")


# ----------------------------------------------------------------------------
# Leitura das saidas
# ----------------------------------------------------------------------------


def lista_arquivos(exp: dict) -> list[str]:
    arqs = sorted(glob.glob(exp["arquivos"]))
    if not arqs:
        raise FileNotFoundError(f"Nenhum arquivo para o padrao: {exp['arquivos']}")
    return arqs


def _xtimes(ds: xr.Dataset) -> list[str]:
    if "xtime" in ds:
        out = []
        for x in ds["xtime"].values:
            if isinstance(x, np.ndarray):
                s = b"".join(x).decode(errors="ignore")
            elif isinstance(x, (bytes, np.bytes_)):
                s = x.decode(errors="ignore")
            else:
                s = str(x)
            out.append(s.strip("\x00 ").strip())
        return out
    return [f"t{i}" for i in range(ds.sizes["Time"])]


def le_campo(exp: dict, var: str, nivel=None, tempos="ultimo"):
    """Le `var` das saidas do experimento.

    nivel: None (todos), inteiro (0 = superficie) ou slice (ex.: slice(-5, None) = topo).
    Retorna (lista de xtime, array [Time, nCells(, k)]).
    """
    arqs = lista_arquivos(exp)
    if tempos == "ultimo":
        arqs = arqs[-1:]
    xts, dados = [], []
    for f in arqs:
        with xr.open_dataset(f, decode_times=False) as ds:
            if var not in ds:
                raise KeyError(f"Variavel '{var}' nao existe em {f}")
            da = ds[var]
            if nivel is not None:
                vd = [d for d in da.dims if d.startswith("nVertLevels")]
                if vd:
                    da = da.isel({vd[0]: nivel})
            xt = _xtimes(ds)
            if tempos == "ultimo":
                da, xt = da.isel(Time=[-1]), xt[-1:]
            dados.append(np.asarray(da.values, dtype=float))
            xts += xt
    return xts, np.concatenate(dados, axis=0)


def horas(xtimes: list[str]) -> list[float]:
    try:
        ts = [datetime.strptime(x[:19], "%Y-%m-%d_%H:%M:%S") for x in xtimes]
        return [(t - ts[0]).total_seconds() / 3600.0 for t in ts]
    except ValueError:
        return list(range(len(xtimes)))


# ----------------------------------------------------------------------------
# Malha e regrade
# ----------------------------------------------------------------------------


class Malha:
    def __init__(self, caminho: str):
        with xr.open_dataset(caminho, decode_times=False) as ds:
            self.lat = np.asarray(ds["latCell"].values, dtype=float)  # rad
            self.lon = np.asarray(ds["lonCell"].values, dtype=float) % (2 * np.pi)
            self.area = np.asarray(ds["areaCell"].values, dtype=float)
            self.viz = None
            if "cellsOnCell" in ds and "nEdgesOnCell" in ds:
                c = np.asarray(ds["cellsOnCell"].values).astype(int) - 1  # 1-based -> 0-based
                n = np.asarray(ds["nEdgesOnCell"].values).astype(int)
                self.mask = np.arange(c.shape[1])[None, :] < n[:, None]
                c[~self.mask] = 0
                self.viz = c
        self.n = self.lat.size

    @property
    def dx_km(self) -> float:
        """Espacamento nominal estimado pela area media (hexagono)."""
        return float(np.sqrt(2.0 * self.area.mean() / np.sqrt(3.0)) / 1000.0)

    @property
    def lat_deg(self):
        return np.rad2deg(self.lat)

    @property
    def lon_deg(self):
        return np.rad2deg(self.lon)


def carrega_malha(cfg: dict) -> Malha:
    g = cfg["geral"]
    caminho = g.get("malha") or lista_arquivos(cfg["experimentos"][g["controle"]])[0]
    return Malha(caminho)


def _xyz(lat, lon):
    return np.column_stack([np.cos(lat) * np.cos(lon), np.cos(lat) * np.sin(lon), np.sin(lat)])


class Regrade:
    """Regrade vizinho-mais-proximo da malha nao estruturada para lat-lon."""

    def __init__(self, malha: Malha, cfg: dict):
        g = cfg["geral"]
        self.dx_km = float(g.get("dx_nominal_km", malha.dx_km))
        la0 = float(np.rad2deg(malha.lat.min()))
        la1 = float(np.rad2deg(malha.lat.max()))
        lo0 = float(malha.lon_deg.min())
        lo1 = float(malha.lon_deg.max())
        flat = g.get("faixa_lat") or [max(la0, -70.0), min(la1, 70.0)]
        flon = g.get("faixa_lon") or [lo0, lo1]
        self.regional = bool(g.get("regional", (lo1 - lo0) < 350.0))
        d = self.dx_km / 111.19  # grau
        self.lat = np.arange(flat[0], flat[1] + 1e-9, d)
        self.lon = np.arange(flon[0], flon[1], d)
        la, lo = np.meshgrid(np.deg2rad(self.lat), np.deg2rad(self.lon), indexing="ij")
        alvo = _xyz(la.ravel(), lo.ravel())
        tree = cKDTree(_xyz(malha.lat, malha.lon))
        dist, self.idx = tree.query(alvo)
        self.fora = (dist * R_TERRA / 1000.0) > 2.0 * self.dx_km  # longe de qualquer celula
        self.shape = (self.lat.size, self.lon.size)

    def __call__(self, campo: np.ndarray) -> np.ndarray:
        """campo [..., nCells] -> [..., nlat, nlon] (NaN fora do dominio)."""
        out = campo[..., self.idx].astype(float)
        out[..., self.fora] = np.nan
        return out.reshape(campo.shape[:-1] + self.shape)

    @property
    def peso_lat(self):
        return np.cos(np.deg2rad(self.lat))[:, None] * np.ones(self.shape)


def rms_ponderado(x: np.ndarray, peso: np.ndarray) -> float:
    ok = np.isfinite(x)
    return float(np.sqrt(np.nansum(peso * np.where(ok, x, 0.0) ** 2) / peso[ok].sum()))


# ----------------------------------------------------------------------------
# Logs do modelo
# ----------------------------------------------------------------------------

_NUM = r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eEdD][-+]?\d+)?|[-+]?(?:nan|inf(?:inity)?)"
RE_PASSO = re.compile(r"Begin timestep\s+(\S+)", re.I)
RE_MINMAX = re.compile(rf"global\s+min\s*,?\s*max\s+(\w+)\s+({_NUM})\s+({_NUM})", re.I)
RE_TIMING = re.compile(rf"Timing for integration step:\s*({_NUM})", re.I)
RE_FIM = re.compile(r"Finished running the atmosphere core", re.I)
RE_ERRO = re.compile(r"CRITICAL ERROR|\bERROR\b", re.I)


def _num(s: str) -> float:
    return float(s.replace("d", "e").replace("D", "e"))


def le_log(caminho: str, re_minmax: str | None = None) -> dict:
    """Extrai passos, min/max globais, tempo por passo e fim do log do MPAS."""
    rx = re.compile(re_minmax, re.I) if re_minmax else RE_MINMAX
    passos: list[dict] = []
    timings: list[float] = []
    terminou = False
    erros: list[str] = []
    atual = None
    with open(caminho, errors="ignore") as f:
        for linha in f:
            m = RE_PASSO.search(linha)
            if m:
                atual = {"tempo": m.group(1)}
                passos.append(atual)
                continue
            m = rx.search(linha)
            if m and atual is not None:
                atual[m.group(1).lower()] = (_num(m.group(2)), _num(m.group(3)))
                continue
            m = RE_TIMING.search(linha)
            if m:
                timings.append(_num(m.group(1)))
                continue
            if RE_FIM.search(linha):
                terminou = True
            elif RE_ERRO.search(linha) and len(erros) < 5:
                erros.append(linha.strip())
    return {"passos": passos, "timings": timings, "terminou": terminou, "erros": erros}


# ----------------------------------------------------------------------------
# Graficos
# ----------------------------------------------------------------------------


def estilo(nome: str, cfg: dict, i: int) -> dict:
    import matplotlib.pyplot as plt

    if nome == cfg["geral"]["controle"]:
        return {"color": "black", "lw": 2.2, "zorder": 5}
    cores = plt.get_cmap("tab10").colors
    return {"color": cores[(i - 1) % 10], "lw": 1.6}


def salva_fig(fig, nome: str, cfg: dict) -> str:
    caminho = os.path.join(cfg["geral"]["saida"], nome)
    fig.savefig(caminho, dpi=150, bbox_inches="tight")
    import matplotlib.pyplot as plt

    plt.close(fig)
    print(f"  figura: {caminho}")
    return caminho


def salva_csv(df, nome: str, cfg: dict) -> str:
    caminho = os.path.join(cfg["geral"]["saida"], nome)
    df.to_csv(caminho, index=False, float_format="%.6g")
    print(f"  tabela: {caminho}")
    return caminho
