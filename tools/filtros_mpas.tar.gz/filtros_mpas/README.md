# Analise dos filtros do MPAS/MONAN

Scripts em Python para as quatro metricas do slide 20 ("Como medir o efeito de cada filtro").
Cada teste (A1, B1, ...) e comparado ao controle (CTRL) com a mesma condicao inicial,
fisica, dt e duracao.

| Metrica do slide | Script               | O que calcula                              |                                           |
|------------------|----------------------|--------------------------------------------|-------------------------------------------|
| Ruido            | `m1_ruido.py`        | rugosidade 2dx de theta na malha nativa;   | `ruido_metricas.csv`, `ruido_<serie>.png` |
|                  |                      | RMS de divergencia e vorticidade (todas    |                                           |
|                  |                      | as escalas e so poucos dx); max \|w\| nos  |                                           |
|                  |                      | niveis do topo                             |                                           |
|                  |                      | 
| Energia          | `m2_espectro.py`     | espectro zonal de energia cinetica, razao  |  `espectro_*.csv`, `espectro_<serie>.png` |
|                  |                      | ao controle, lambda_50, energia em 2-6dx   |                                           |
|                  |                      |e fracao abaixo de 6dx                      |                                           |
| Estabilidade     | `m3_estabilidade.py` | max \|u\| e max \|w\| por passo (do log),  | `estabilidade_resumo.csv`,                |
|                  |                      |termino normal, primeiro passo com explosao | `estabilidade_<serie>.png`                |
| Impacto no tempo | `m4_impacto.py`      | RMSE e vies ponderados pela area, mapas de | `impacto_resumo.csv`,  |
|                  |                      | diferenca ao controle, tempo por passo     |`impacto_<var>_<serie>.png`,               |
|                  |                      |                                            |`impacto_custo.png`                        |
## Uso

```bash
pip install -r requirements.txt          # Python 3.9+ (em < 3.11 instala tomli)
cp experimentos.toml meu_caso.toml       # edite caminhos, nivel e experimentos
python run_all.py meu_caso.toml          # as quatro analises
python run_all.py meu_caso.toml --so ruido espectro   # so algumas
```

Cada `m*.py` tambem roda sozinho: `python m2_espectro.py meu_caso.toml`.

## O que a saida do modelo precisa ter

- Nos arquivos de saida (`history` ou `diag`): `uReconstructZonal`, `uReconstructMeridional`,
  `w`, `theta` e `xtime`. Os nomes mudam em `[ruido]`/`[espectro]`/`[impacto]`.
- Na malha (`malha =` ou no primeiro arquivo do controle): `latCell`, `lonCell`, `areaCell`.
  Com `cellsOnCell` e `nEdgesOnCell` a rugosidade e calculada na malha nativa; sem eles, usa-se
  o laplaciano de 5 pontos na grade lat-lon. Os valores absolutos dos dois caminhos nao sao
  comparaveis entre si; compare sempre dentro do mesmo caminho.
- No log (`log.atmosphere.0000.out`): linhas de min/max global de u e w, que exigem
  `config_print_global_minmax_vel = true`, e `Timing for integration step`.

## Pontos a conferir no seu caso

1. **Formato do log.** O padrao procurado e `global min, max <var> <min> <max>`,
   `Begin timestep <tempo>` e `Timing for integration step: <s>`. Foi escrito de memoria, sem
   um log real do MPAS para comparar. Se o seu for diferente, ajuste `regex_minmax` em
   `[estabilidade]` (tres grupos: variavel, minimo, maximo) ou as expressoes no inicio de
   `fm_common.py`.
2. **Topo do modelo.** `max |w|` usa os ultimos niveis do eixo vertical (no MPAS o indice 0 e
   a superficie).
3. **Regrade.** Vizinho mais proximo para uma grade lat-lon com espacamento ~ dx. Em malhas
   regionais, defina `faixa_lat` e `faixa_lon` dentro do dominio; o espectro usa janela de Hann.
4. **Espectro.** Zonal, por faixa de latitudes, em um nivel. A caixa mais fina (perto de 2dx)
   e afetada pelo regrade; interprete `lambda_50_km` como comparacao relativa ao controle.
5. **Validacao.** Testado so com dados sinteticos (`teste/`), que verificam o codigo e nao a
   fisica: `python teste/gera_dados_sinteticos.py teste/dados_sinteticos` e depois
   `python run_all.py teste/experimentos_teste.toml`. Rode primeiro em um par de simulacoes
   curtas suas e confira os numeros contra as figuras do modelo.
