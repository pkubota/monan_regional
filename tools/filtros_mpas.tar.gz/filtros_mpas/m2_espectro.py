"""m2_espectro.py: metrica 2 do slide 20 (energia).

Espectro zonal de energia cinetica horizontal por comprimento de onda, em um nivel,
medio na faixa de latitudes e nos instantes lidos. Compara cada experimento ao controle:
  - lambda_50   : maior comprimento de onda (km) onde E/E_ctrl cai abaixo de 0,5
                  (duas caixas seguidas). Mede o quanto o filtro amortece as escalas resolvidas.
  - razao_2_6dx : energia entre 2dx e 6dx dividida pela do controle.
  - frac_6dx    : fracao da energia total em lambda < 6dx (indice de ruido).
Saidas: espectro_<serie>.png, espectro_dados.csv e espectro_resumo.csv.
"""
from __future__ import annotations

import argparse

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import fm_common as fm


def espectro_zonal(u, v, lat_deg, lon_deg, regional, bins_k):
    """Densidade espectral de EC [m^3 s^-2] por caixa de numero de onda; u, v [nlat, nlon]."""
    nlon = u.shape[1]
    dlon = np.deg2rad(lon_deg[1] - lon_deg[0])
    nb = len(bins_k) - 1
    soma, cont = np.zeros(nb), np.zeros(nb)
    jan = np.hanning(nlon) if regional else np.ones(nlon)
    norm = np.mean(jan**2)
    m = np.arange(nlon // 2 + 1)
    for i, lat in enumerate(lat_deg):
        if not (np.all(np.isfinite(u[i])) and np.all(np.isfinite(v[i]))):
            continue
        lx = nlon * dlon * fm.R_TERRA * np.cos(np.deg2rad(lat))
        k, dk = 2 * np.pi * m / lx, 2 * np.pi / lx
        fu = np.fft.rfft((u[i] - u[i].mean()) * jan)
        fv = np.fft.rfft((v[i] - v[i].mean()) * jan)
        p = (np.abs(fu) ** 2 + np.abs(fv) ** 2) / nlon**2 / norm
        p[1 : (nlon + 1) // 2] *= 2.0  # espectro unilateral
        e = 0.5 * p / dk
        ix = np.digitize(k, bins_k) - 1
        ok = (ix >= 0) & (ix < nb) & (m > 0)
        np.add.at(soma, ix[ok], e[ok])
        np.add.at(cont, ix[ok], 1)
    return soma / np.where(cont > 0, cont, np.nan)


def lambda_50(lam, razao):
    """Primeiro lambda (de grande para pequeno) onde a razao fica < 0,5 por duas caixas seguidas."""
    for i in range(len(lam) - 1):
        if razao[i] < 0.5 and razao[i + 1] < 0.5:
            return float(lam[i])
    return np.nan


def main(cfg: dict) -> pd.DataFrame:
    c = cfg["espectro"]
    nivel = int(c.get("nivel", cfg["geral"]["nivel"]))
    tempos = cfg["geral"]["tempos"]
    malha = fm.carrega_malha(cfg)
    rg = fm.Regrade(malha, cfg)
    dx = rg.dx_km
    lam_max = float(c.get("lambda_max_km", 2000.0))
    nb = int(c.get("n_caixas", 40))
    k_min, k_max = 2 * np.pi / (lam_max * 1e3), np.pi / (dx * 1e3)
    bins_k = np.geomspace(k_min, k_max, nb + 1)
    k_c = np.sqrt(bins_k[:-1] * bins_k[1:])
    lam = 2 * np.pi / k_c / 1e3  # km, decrescente
    dk = np.diff(bins_k)

    espectros = {}
    for nome, exp in fm.experimentos(cfg).items():
        print(f"[espectro] {nome}")
        _, uz = fm.le_campo(exp, c.get("u", "uReconstructZonal"), nivel, tempos)
        _, vm = fm.le_campo(exp, c.get("v", "uReconstructMeridional"), nivel, tempos)
        es = [espectro_zonal(rg(uz[i]), rg(vm[i]), rg.lat, rg.lon, rg.regional, bins_k)
              for i in range(uz.shape[0])]
        espectros[nome] = np.nanmean(es, axis=0)

    ctrl = cfg["geral"]["controle"]
    faixa = (lam >= 2 * dx) & (lam <= 6 * dx)
    ruido = lam < 6 * dx
    linhas = []
    for nome, e in espectros.items():
        ec = espectros[ctrl]
        razao = e / ec
        linhas.append({
            "exp": nome, "serie": fm.serie_de(cfg, nome),
            "EC_total": float(np.nansum(e * dk)),
            "frac_6dx": float(np.nansum((e * dk)[ruido]) / np.nansum(e * dk)),
            "razao_2_6dx": float(np.nansum((e * dk)[faixa]) / np.nansum((ec * dk)[faixa])),
            "lambda_50_km": lambda_50(lam, razao) if nome != ctrl else np.nan,
        })
    resumo = pd.DataFrame(linhas)
    fm.salva_csv(resumo, "espectro_resumo.csv", cfg)
    dados = pd.DataFrame({"lambda_km": lam, **{f"E_{n}": e for n, e in espectros.items()}})
    fm.salva_csv(dados, "espectro_dados.csv", cfg)

    ancora = int(np.argmin(np.abs(lam - 15 * dx)))
    for serie, nomes in fm.series(cfg).items():
        fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 4.8))
        for i, n in enumerate(nomes):
            est = fm.estilo(n, cfg, i)
            a1.loglog(lam, espectros[n], label=n, **est)
            a2.semilogx(lam, espectros[n] / espectros[ctrl], label=n, **est)
        l0 = lam[ancora]
        e0 = espectros[ctrl][ancora] * 2
        ll = np.geomspace(4 * dx, 40 * dx, 20)
        a1.loglog(ll, e0 * (ll / l0) ** 3, "k:", lw=1)
        a1.loglog(ll, e0 * (ll / l0) ** (5 / 3), "k--", lw=1)
        a1.text(ll[1], e0 * (ll[1] / l0) ** 3 * 0.55, "k^-3", fontsize=9, ha="left")
        a1.text(ll[1], e0 * (ll[1] / l0) ** (5 / 3) * 1.4, "k^-5/3", fontsize=9, ha="left")
        for a in (a1, a2):
            a.invert_xaxis()
            a.axvline(2 * dx, color="gray", ls=":", lw=1)
            a.axvline(6 * dx, color="gray", ls=":", lw=1)
            a.set_xlabel("comprimento de onda zonal (km)")
            a.grid(alpha=0.3, which="both")
        a1.set_ylabel("EC espectral (m^3 s^-2)")
        a1.set_title("Espectro de energia cinetica")
        a2.axhline(1.0, color="gray", lw=1)
        a2.axhline(0.5, color="gray", lw=1, ls="--")
        rmax = np.nanmax([np.nanmax(espectros[n] / espectros[ctrl]) for n in nomes])
        a2.set_ylim(0, max(2.0, min(1.1 * rmax, 8.0)))
        a2.set_title("Razao ao controle")
        a1.legend(fontsize=8)
        fig.suptitle(f"Serie {serie}: nivel {nivel}, lambda = 2dx e 6dx tracejados", fontweight="bold")
        fig.tight_layout()
        fm.salva_fig(fig, f"espectro_{serie}.png", cfg)
    return resumo


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("config")
    main(fm.carrega_config(ap.parse_args().config))
